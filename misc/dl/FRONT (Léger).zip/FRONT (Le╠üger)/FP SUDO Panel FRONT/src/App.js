import React from 'react';
import '@radix-ui/themes/styles.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import User from "./utils/User";
import Infrastructure from "./components/Infrastructure";
import APIError from "./components/APIError";
import Home from "./components/Home";
import Logs from "./components/Logs";
import Signin from "./components/Signin";
import InfraForm from "./components/forms/InfraForm";
import ProtectedRoute from "./utils/ProtectedRoute";
import Rack from "./components/Rack";
import RackForm from "./components/forms/RackForm";
import Register from "./components/Register";
import AccountList from "./components/AccountList";
import Users from "./components/Users";

function App() {

    if(checkAPI()) {
        return (<Router>
            <div className="App">
                <Routes>
                    <Route  path="/" element={
                            <ProtectedRoute>
                            <Home/>
                            </ProtectedRoute>
                    }/>
                    <Route path="/infra" element={
                        <ProtectedRoute>
                            <Infrastructure/>
                        </ProtectedRoute>
                    }/>
                    <Route path="/infra/create" element={
                        <ProtectedRoute>
                            <InfraForm/>
                        </ProtectedRoute>
                    }/>
                    <Route path="/infra/edit/:hardwareID" element={
                        <ProtectedRoute>
                            <InfraForm/>
                        </ProtectedRoute>
                    }/>
                    <Route path="/rack" element={
                        <ProtectedRoute>
                            <Rack/>
                        </ProtectedRoute>
                    }/>
                    <Route path="/rack/create" element={
                        <ProtectedRoute>
                            <RackForm/>
                        </ProtectedRoute>
                    }/>
                    <Route path="/logs/:logPage" element={
                        <ProtectedRoute>
                            <Logs/>
                        </ProtectedRoute>
                    }/>
                    <Route path="/accounts/:query?" element={
                        <ProtectedRoute>
                            <AccountList/>
                        </ProtectedRoute>
                    }/>
                    <Route path="/users" element={
                        <ProtectedRoute>
                            <Users/>
                        </ProtectedRoute>
                    }/>
                    <Route path="/login" element={
                        <Signin/>
                    }/>
                    <Route path="/register" element={
                        <Register/>
                    }/>
                </Routes>
            </div>
        </Router>);
    } else {
        return (<APIError></APIError>)
    }
}

function checkAPI() {
    try {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', 'http://'+process.env.REACT_APP_API+':1222/', false);
        xhr.send();
        if (xhr.status === 200) {
            return true;
        } else {
            return false;
        }
    } catch (error) {
        return false;
    }
}

export default App;
