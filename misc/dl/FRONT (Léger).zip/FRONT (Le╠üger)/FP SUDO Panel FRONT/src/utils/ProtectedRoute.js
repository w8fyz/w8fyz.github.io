import React from 'react'
import {Navigate, useLocation} from "react-router-dom"
import User from "./User";

const ProtectedRoute = ({children}) => {
    let location = useLocation();

    if(!User.isConnected()) {
        return <Navigate to="/login" state={{ from: location}} replace />
    }
    return children

};

export default ProtectedRoute;