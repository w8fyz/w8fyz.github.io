class HardwareType {
    constructor(id, name, icon) {
        this.id = id;
        this.name = name;
        this.icon = icon;
    }
}


export default HardwareType;