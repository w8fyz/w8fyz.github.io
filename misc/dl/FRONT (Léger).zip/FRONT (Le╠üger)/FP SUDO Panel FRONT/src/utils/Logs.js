class Logs {

    async getPage(page) {
        try {
            const response = await fetch('http://'+process.env.REACT_APP_API+':1222/v1/logs/get/'+page, {
                method: 'GET',
                credentials: 'include',
            });

            if (response.status === 200) {
                return await response.json();
            } else if (response.status === 401) {
                return null;
            } else {
                console.error("Error while fetching Logs:", response.statusText);
                return null;
            }
        } catch (error) {
            console.error("Error while fetching Logs:", error);
            return null;
        }
    }

    async haveNext(page) {
        try {
            const response = await fetch('http://'+process.env.REACT_APP_API+':1222/v1/logs/havenext/'+page, {
                method: 'GET',
                credentials: 'include',
            });

            if (response.status === 200) {
                return await response.json();
            } else if (response.status === 401) {
                return null;
            } else {
                console.error("Error while fetching racks:", response.statusText);
                return null;
            }
        } catch (error) {
            console.error("Error while fetching racks:", error);
            return null;
        }
    }
}

const logs = new Logs();
export default logs;