import HardwareType from "./hardware/HardwareType";

class Hardware {

    types = [
        new HardwareType(0, "PTERO", "/hardware/ptero.svg"),
    new HardwareType(1, "SERVER", "/hardware/server.svg"),
    new HardwareType(2, "ROUTER", "/hardware/misc.svg"),
    new HardwareType(3, "SWITCH", "/hardware/misc.svg"),
    new HardwareType(4, "MISC", "/hardware/misc.svg")
];

    getTypes(){
        return this.types;
    }

    async get(id) {
        try {
            const response = await fetch('http://'+process.env.REACT_APP_API+':1222/v1/hardware/get/'+id, {
                method: 'GET',
                credentials: 'include',
            });

            if (response.status === 200) {
                return await response.json();
            } else if (response.status === 401) {
                return null;
            } else {
                console.error("Error while fetching hardware:", response.statusText);
                return null;
            }
        } catch (error) {
            console.error("Error while fetching hardware:", error);
            return null;
        }
    }

    async getList(query) {
        try {
            const response = await fetch('http://'+process.env.REACT_APP_API+':1222/v1/hardware/query', {
                method: 'POST',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(query)
            });

            if (response.status === 200) {
                return await response.json();
            } else if (response.status === 401) {
                return null;
            } else {
                console.error("Error while fetching hardwares:", response.statusText);
                return null;
            }
        } catch (error) {
            console.error("Error while fetching hardwares:", error);
            return null;
        }
    }



    getHardwareTypeByID(id) {
        return this.getTypes().find((type) => id == type.id);
    }

    async delete(id) {
        const response = await fetch('http://'+process.env.REACT_APP_API+':1222/v1/hardware/delete/'+id, {
            method: 'GET',
            credentials: "include",
        });
        console.log(response);
        return await response.json();
    } catch (error) {
        console.error("Error while fetching hardwares:", error);
        return null;
    }

    async save(request, data) {
        return fetch(request, {
            method: 'POST',
            credentials: "include",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        })
            .then(data => data.json()).catch(err => console.log(JSON.stringify(data)));
    }

}
const hardware = new Hardware();
export default hardware;
