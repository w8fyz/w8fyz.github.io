class User {
    getSelf() {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', 'http://'+process.env.REACT_APP_API+':1222/v1/user/me', false);
        xhr.withCredentials = true;
        xhr.send();
        if (xhr.status === 200) {
            return JSON.parse(xhr.responseText);
        } else if (xhr.status === 401) {
            return null;
        } else {
            console.error("Error while fetching user:", xhr.statusText);
            return null;
        }
    }

    async delete(id) {
        try {
            const response = await fetch('http://'+process.env.REACT_APP_API+':1222/v1/user/delete/'+id, {
                method: 'GET',
                credentials: 'include',
            });

            if (response.status === 200) {
                return await response.json();
            } else if (response.status === 401) {
                return null;
            } else {
                console.error("Error while fetching racks:", response.statusText);
                return null;
            }
        } catch (error) {
            console.error("Error while fetching racks:", error);
            return null;
        }
    }

    async getAll() {
        try {
            const response = await fetch('http://'+process.env.REACT_APP_API+':1222/v1/user/all', {
                method: 'GET',
                credentials: 'include',
            });

            if (response.status === 200) {
                return await response.json();
            } else if (response.status === 401) {
                return null;
            } else {
                console.error("Error while fetching racks:", response.statusText);
                return null;
            }
        } catch (error) {
            console.error("Error while fetching racks:", error);
            return null;
        }
    }

    isConnected() {
        const user = this.getSelf();
        return user !== null;

    }

    disconnect() {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', 'http://'+process.env.REACT_APP_API+':1222/v1/auth/logout', false);
        xhr.withCredentials = true;
        xhr.send();
    }

    needFirstUser() {
        const xhr = new XMLHttpRequest();
        xhr.open('GET', 'http://'+process.env.REACT_APP_API+':1222/v1/user/needFirstUser', false);
        xhr.withCredentials = true;
        xhr.send();
        if (xhr.status === 200) {
            let response = JSON.parse(xhr.responseText);
            console.log(response.message)
            return (response.message === 'true');
        } else if (xhr.status === 401) {
            return null;
        } else {
            console.error("Error while fetching haveAUser:", xhr.statusText);
            return null;
        }
    }
}

const user = new User();
export default user;
