class Rack {

    async getAll() {
        try {
            const response = await fetch('http://'+process.env.REACT_APP_API+':1222/v1/rack/get', {
                method: 'GET',
                credentials: 'include',
            });

            if (response.status === 200) {
                return await response.json();
            } else if (response.status === 401) {
                return null;
            } else {
                console.error("Error while fetching racks:", response.statusText);
                return null;
            }
        } catch (error) {
            console.error("Error while fetching racks:", error);
            return null;
        }
    }

    getRackByIDFromSource(id, source) {
        return source.find((rack) => id == rack.id);
    }

    async delete(id) {
        try {
            const response = await fetch('http://'+process.env.REACT_APP_API+':1222/v1/rack/delete/'+id, {
                method: 'GET',
                credentials: 'include',
            });
            return await response.json()
        } catch (error) {
            console.error("Error while fetching racks:", error);
            return null;
        }
    }

    async save(name) {
        try {
            const response = await fetch('http://'+process.env.REACT_APP_API+':1222/v1/rack/create/'+name, {
                method: 'GET',
                credentials: 'include',
            });
            return await response.json()
        } catch (error) {
            console.error("Error while fetching racks:", error);
            return null;
        }
    }
}
const rack = new Rack();
export default rack;
