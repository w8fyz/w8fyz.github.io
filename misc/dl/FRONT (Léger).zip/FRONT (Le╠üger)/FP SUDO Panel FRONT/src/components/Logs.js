import React, {useEffect, useState} from "react";
import Header from "./parts/Header";
import "../css/logs.css";
import {Toaster} from "react-hot-toast";
import {useNavigate, useParams} from "react-router-dom";
import Logs from "../utils/Logs";
import Log from "./parts/Log";
import Arrow from "./parts/Arrow";
import { FaArrowLeft } from "react-icons/fa";
import { FaArrowRight } from "react-icons/fa";
import async from "async";

export default function Audits() {
    const navigate = useNavigate();
    let { logPage } = useParams();
    logPage = parseInt(logPage) || 0;

    const [hasFetchedNext, setHasFetchedNext] = useState(false);
    const [arrows, setArrows] = useState([]);
    const [logs, setLogs] = useState([]);
    const [hasFetchedLogs, setHasFetchedLogs] = useState(false);

    useEffect(() => {
        const fetchLogs = async () => {
            try {
                const logsData = await Logs.getPage(logPage);
                setHasFetchedLogs(true);
                const formattedLogs = logsData.map((log) => (
                    <Log
                        key={log.timestamp}
                        fullName={log.fullName}
                        message={log.message}
                        timestamp={log.timestamp}
                    />
                ));
                setLogs(formattedLogs);
            } catch (exception) {
                console.log(exception);
            }
        };

        const refreshPage = (newPage) => {
            navigate(`/logs/${newPage}`);
            setHasFetchedLogs(false);
            setHasFetchedNext(false);
        };

        const fetchArrow = async () => {
            try {
                const arrows = [];
                const nextResponse = await Logs.haveNext(logPage);
                console.log(nextResponse);

                if (logPage > 0) {
                    arrows.push(
                        <Arrow
                            symbol={<FaArrowLeft />}
                            handleClick={() => refreshPage(logPage - 1)}
                        />
                    );
                } else {
                    arrows.push(
                        <Arrow
                            symbol={null}
                            handleClick={() => {}}
                        />
                    );
                }

                if (nextResponse.message === "true") {
                    arrows.push(
                        <Arrow
                            symbol={<FaArrowRight />}
                            handleClick={() => refreshPage(logPage + 1)}
                        />
                    );
                }

                setArrows(arrows);
                setHasFetchedNext(true);
            } catch (exception) {
                console.log(exception);
            }
        };

        if (!hasFetchedLogs) {
            fetchLogs();
        }
        if (!hasFetchedNext) {
            fetchArrow();
        }
    }, [hasFetchedLogs, hasFetchedNext, logPage]);

    return (
        <div className="app-container">
            <Toaster />
            <Header title="Audits FP-SUDO" back={true} disconnect={true} />
            <div id="logs-container">
                {logs}
            </div>
            <div id="arrow-container">
                {arrows}
            </div>
        </div>
    );
}