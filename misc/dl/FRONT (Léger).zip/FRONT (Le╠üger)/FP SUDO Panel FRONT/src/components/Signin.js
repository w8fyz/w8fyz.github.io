import React, {useEffect, useState} from 'react';
import {Button, TextField} from "@material-ui/core";
import Header from "./parts/Header";
import '../css/main.css';
import toast, {Toaster} from "react-hot-toast";
import {Navigate, useNavigate} from "react-router-dom";
import User from "../utils/User";
import Register from "./Register";


async function loginUser(credentials) {
    return fetch('http://'+process.env.REACT_APP_API+':1222/v1/auth/login', {
        method: 'POST',
        credentials: "include",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(credentials)
    })
        .then(data => data.json()).catch(err => console.log(JSON.stringify(credentials)));
}


export default function Signin() {
    const [login, setLogin] = useState();
    const [password, setPassword] = useState();
    const [verificationToken, setVerificationToken] = useState();
    const [checkedConnexion, setCheckedConnexion] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        if(!checkedConnexion) {
            if(User.isConnected()) {
                return <Navigate to="/" replace></Navigate>
            }
            setCheckedConnexion(true);
        }
    }, [checkedConnexion]);

    if(User.needFirstUser()) {
        return <Navigate to="/register" replace></Navigate>
    }


    const handleSubmit = async e => {
        e.preventDefault();
        const loading = toast.loading("Chargement...");
        const response = await loginUser({
            login,
            password,
            verificationToken
        });
        if (response.code === 200) {
            toast.success('Connexion réussi', {
                id: loading,
            });
            navigate("/");
        } else {
            toast.error(response.message, {
                id: loading,
            });
        }
    }

    return (
        <div className="app-container">
            <Toaster/>
            <Header title="Connexion via FP-SUDO" subtitle="Toute action sera enregistrée." disconnect={false}/>
                <form noValidate onSubmit={handleSubmit}>
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="email"
                        name="email"
                        label="Identifiant"
                        onChange={e => setLogin(e.target.value)}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="password"
                        name="password"
                        label="Mot de passe"
                        type="password"
                        onChange={e => setPassword(e.target.value)}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="2fa"
                        name="2fa"
                        label="Double authentification"
                        type="text"
                        onChange={e => setVerificationToken(e.target.value)}
                    />
                    <Button
                        type="submit"
                        className="login_btn"
                        variant="contained"
                        color="primary"
                        fullWidth
                        size="large"
                    >
                        Connexion
                    </Button>
                </form>
            <h2>BYPASS ACTUEL: TOTP contournable par la valeur "000000"</h2>
        </div>
    );
}