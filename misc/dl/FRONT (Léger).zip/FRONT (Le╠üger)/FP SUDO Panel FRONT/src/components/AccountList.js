import React, {useEffect, useState} from "react";
import Header from "./parts/Header";
import {Link, useNavigate, useParams} from "react-router-dom";
import "../css/accounts.css";
import Accounts from "../utils/Accounts";
import AccountEntity from "./parts/AccountEntity";
import toast, {Toaster} from "react-hot-toast";
import {
    Button,
    Dialog, DialogActions, DialogContent, DialogContentText,
    DialogTitle, TextField,
} from "@material-ui/core";


export default function AccountList() {
    const navigate = useNavigate();
    let {query} = useParams();
    const [accs, setAccs] = useState([]);
    const [hasFetchedAccounts, setHasFetchedAccounts] = useState(false);
    const [deletingAccount, setDeletingAccount] = useState({});
    const [isDialogOpen, setDialogOpen] = useState(false);
    const [isCreatingAccount, setCreatingAccount] = useState(false);

    useEffect(() => {
        const fetchAccounts = async () => {
            try {
                const accountsData = await Accounts.getList(query);
                setHasFetchedAccounts(true)
                const formatedAccs = accountsData.map((account) => {
                    return (
                        <AccountEntity
                            id={account.id}
                            name={account.name}
                            username={account.username}
                            handleDelete={() => askConfirmDeleteAccount(account)
                            }
                        />
                    );
                });
                setAccs(formatedAccs);
            } catch (exception) {
                console.log(exception);
            }
        };

        if(!hasFetchedAccounts) {
            fetchAccounts();
        }


    }, [hasFetchedAccounts]);

    const askConfirmDeleteAccount = (account) => {
        setDeletingAccount(account);
        setDialogOpen(true);
    }

    const handleCreateAccount = async (formJson) => {
        const loading = toast.loading("Chargement...");
        const response = await Accounts.save("http://"+process.env.REACT_APP_API+":1222/v1/accounts/create/", formJson);
        if (response.code === 200) {
            toast.success('Création réussie', {
                id: loading,
            });
            setHasFetchedAccounts(false);

        } else {
            toast.error(response.message, {
                id: loading,
            });
        }
        setDialogOpen(false);
    }

    const handleDeleteAccount = async () => {
        const loading = toast.loading("Chargement...");
        const response = await Accounts.delete(deletingAccount.id);
        if (response.code === 200) {
            toast.success('Supression réussie', {
                id: loading,
            });
            setHasFetchedAccounts(false);

        } else {
            toast.error(response.message, {
                id: loading,
            });
        }
        setDialogOpen(false);
    }

    return (
        <div className="app-container">
            <Toaster/>
            <Dialog
                open={isCreatingAccount}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                PaperProps={{
                    component: 'form',
                    onSubmit: (event) => {
                        event.preventDefault();
                        const formData = new FormData(event.currentTarget);
                        const formJson = Object.fromEntries(formData.entries());
                        formJson.neededPower = 0;
                        setCreatingAccount(false);
                        handleCreateAccount(formJson);
                    },
                }}
            >
                <DialogTitle>Ajouter un compte</DialogTitle>
                <DialogContent>
                    <TextField
                        autoFocus
                        required
                        id="username"
                        name="username"
                        label="Nom d'utilisateur"
                        type="text"
                    />
                    <TextField
                        autoFocus
                        required
                        id="password"
                        name="password"
                        label="Mot de passe"
                        type="text"
                    />
                    <TextField
                        autoFocus
                        required
                        id="name"
                        name="name"
                        label="Identifiant"
                        type="text"
                    />

                    <DialogContentText>
                        Merci d'utiliser le champ "Identifiant" comme nom d'identification pour le compte et non comme identifiant de connexion.
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => setCreatingAccount(false)}>Annuler</Button>
                    <Button type="submit">
                        Ajouter
                    </Button>
                </DialogActions>
            </Dialog>
            <Dialog
                open={isDialogOpen}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogTitle id="alert-dialog-title">
                    {"Confirmer la supression du compte "+(deletingAccount.id != null ? deletingAccount.name : "")+" ?"}
                </DialogTitle>
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        Cette action est irréversible, les données seront perdues.
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => setDialogOpen(false)}>Annuler</Button>
                    <Button onClick={handleDeleteAccount}>
                        Confirmer
                    </Button>
                </DialogActions>
            </Dialog>
            <Header title="Comptes FP-SUDO" back={true} disconnect={true}/>
            <div id="accounts-control">
                <input placeholder="Recherche..." onChange={(e) => {
                    let val = e.target.value;
                    if(val === "") {
                        val = "*";
                    }
                    navigate(`/accounts/${val}`);
                    setHasFetchedAccounts(false);
                }}/>
                <div id="add-account" onClick={() => {
                    setCreatingAccount(true);
                }}>
                    +
                </div>
            </div>
            <div id="accounts-container">
                {accs}
            </div>
        </div>
    );
}