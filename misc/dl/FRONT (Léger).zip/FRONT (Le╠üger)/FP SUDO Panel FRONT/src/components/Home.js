import User from '../utils/User.js';
import '../css/main.css';
import {FaFileLines, FaServer, FaUserLarge} from "react-icons/fa6";
import Header from "./parts/Header";
import HomeCategory from "./parts/HomeCategory";
import {FaInbox} from "react-icons/fa";
import {Navigate} from "react-router-dom";

export default function Home() {



    const user = User.getSelf();
    return (
        <div className="app-container">
        <Header title="Panel Infrastructure FP-SUDO" subtitle={["Bonjour, ", <strong>{user.firstName}</strong>]} disconnect={true}/>
            <div className="home-container">
                <div className="home-categories">
                <HomeCategory title="Infrastructure" link="/infra" icon={<FaServer/>}/>
                <HomeCategory title="Comptes" link="/accounts/*" icon={<FaInbox/>}/>
                <HomeCategory title="Utilisateurs" link="/users" icon={<FaUserLarge/>}/>
                <HomeCategory title="Audits" link="/logs/0" icon={<FaFileLines/>}/>
                </div>
            </div>
        </div>
    );

}