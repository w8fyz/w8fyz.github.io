import "../../css/userEntity.css"
import React from "react";

function UserEntity({login, firstName, lastName, register, lastLogin, handleDelete}) {

    let registerFormat = formatDate(new Date(register));
    let lastLoginFormat = formatDate(new Date(lastLogin));

    return (
        <div className="user-entity">
        <img src="/hardware/user.svg" className="device-icon"/>
            <h1>{firstName + " " + lastName}</h1>
            <h2>{login}</h2>
            <p><strong>Inscription :</strong></p>
            <p>{registerFormat}</p>
            <p><strong>Dernière connexion :</strong></p>
            <p>{lastLoginFormat}</p>
            <div className="buttons">
                <div onClick={handleDelete}>Supprimer</div>
            </div>
        </div>
    );
}

function formatDate(date) {
    let datePart = [
        date.getDate(),
        date.getMonth()+1,
        date.getFullYear()
    ].map((n, i) => n.toString().padStart(i === 2 ? 4 : 2, "0")).join("/");
    let timePart = [
        date.getHours(),
        date.getMinutes(),
        date.getSeconds()
    ].map((n, i) => n.toString().padStart(2, "0")).join(":");
    return datePart + " " + timePart;
}

export default UserEntity;