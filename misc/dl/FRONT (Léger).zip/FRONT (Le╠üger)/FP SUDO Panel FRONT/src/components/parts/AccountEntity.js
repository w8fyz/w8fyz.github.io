import "../../css/accountEntity.css"
import async from "async";
import {useState} from "react";
import toast from "react-hot-toast";
import {FaTrashCan} from "react-icons/fa6";
import Rack from "../../utils/Rack";
import Accounts from "../../utils/Accounts";

function AccountEntity({ id, name, username, handleDelete }) {
    const [password, setPassword] = useState(null);

    const handlePasswordClick = async (elem) => {
        if (!password) {
            const retrievedPassword = await retrievePassword(id);
            setPassword(retrievedPassword);
            elem.target.innerText = retrievedPassword;
            elem.target.onclick = (event) => {
                copyToClipboard(event, retrievedPassword);
            }
        }
    };

    const unsecuredCopyToClipboard = (text) => {
        const textArea = document.createElement("textarea");
        textArea.value=text;
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        try{
            document.execCommand('copy')
        }catch(err){
            console.error('Unable to copy to clipboard',err)
        }
        document.body.removeChild(textArea);
    };

    const copyToClipboard = (event, password) => {
        if (window.isSecureContext && navigator.clipboard) {
            navigator.clipboard.writeText(password);
        } else {
            unsecuredCopyToClipboard(password);
        }
        toast.success('Mot de passe copié');
    };



    return (
        <div className="account-entity">
            <p className="name">{name}</p>
            <p className="username">{username}</p>
            <div className="control-center">
                <p onClick={handlePasswordClick} className="hidden-password">**********</p>
                <div onClick={handleDelete} className="delete-btn"><FaTrashCan/></div>
            </div>

        </div>
    );
}

async function retrievePassword(id) {
    return await getPassword(id);
}

async function getPassword(id) {
    try {
        const response = await fetch('http://'+process.env.REACT_APP_API+':1222/v1/accounts/getpassword/'+id, {
            method: 'GET',
            credentials: 'include',
        });

        if (response.status === 200) {
            return await response.text();
        } else if (response.status === 401) {
            return null;
        } else {
            console.error("Error while fetching racks:", response.statusText);
            return null;
        }
    } catch (error) {
        console.error("Error while fetching racks:", error);
        return null;
    }
}

export default AccountEntity;