import "../../css/logPart.css"

function Log({fullName, message, timestamp}) {


    return (
        <div className="entry-log">
            <p className="name">{fullName}</p>
            <p className="message">{message}</p>
            <p className="timestamp">{formatDate(new Date(timestamp))}</p>
        </div>
        );
}

function formatDate(date) {
    let datePart = [
        date.getDate(),
        date.getMonth()+1,
        date.getFullYear()
    ].map((n, i) => n.toString().padStart(i === 2 ? 4 : 2, "0")).join("/");
    let timePart = [
        date.getHours(),
        date.getMinutes(),
        date.getSeconds()
    ].map((n, i) => n.toString().padStart(2, "0")).join(":");
    return datePart + " " + timePart;
}

export default Log;