import React from 'react';
import ReactMarkdown from 'react-markdown';
import breaks from 'remark-breaks';
import "../../css/deviceInformation.css"
import {AiFillDelete} from "react-icons/ai";
import {BsFillPencilFill} from "react-icons/bs";

function DeviceInformation({ icon, title, description, buttons, comment, handleDelete, handleEdit }) {
    const finalBtn = [];

    buttons.forEach((btn) => {
        finalBtn.push(
            <a key={btn.key} target="_blank" className="btn-element" href={btn.value}>
                {btn.key}
            </a>)
    });

    return (
        <div className="device-info">
            <div className="control-bar">
                <button onClick={handleDelete}><AiFillDelete/></button>
                <button onClick={handleEdit}><BsFillPencilFill/></button>
            </div>
            <img src={icon} className="device-icon" alt={icon} />
            <h2>{title}</h2>
            <ReactMarkdown remarkPlugins={[breaks]} children={description} />
            <div className="btn-box">{finalBtn}</div>
            <p className="device-comment">{comment}</p>
        </div>
    );
}

export default DeviceInformation;
