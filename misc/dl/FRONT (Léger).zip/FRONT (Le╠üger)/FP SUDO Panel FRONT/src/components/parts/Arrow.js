import "../../css/arrow.css"
import {Button} from "@material-ui/core";
import {useNavigate} from "react-router-dom";

function Arrow({symbol, handleClick}) {
    if(symbol === null) {
        return (
            <div></div>
        );
    }

    return (
        <div onClick={handleClick} className="arrow-direction">
            <h1>{symbol}</h1>
        </div>
    );
}


export default Arrow;