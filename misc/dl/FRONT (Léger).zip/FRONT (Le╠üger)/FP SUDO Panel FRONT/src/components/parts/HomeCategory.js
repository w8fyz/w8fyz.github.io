import {useNavigate} from 'react-router-dom';
import React from "react";
import "../../css/homeCategory.css"


function HomeCategory({title, icon, link}) {
    const navigate = useNavigate();
    return (
        <div onClick={() => navigate(link)} className="home-category">
            {icon}
            <h2>{title}</h2>
        </div>
    );
}

export default HomeCategory;