import React from 'react';
import '../../css/header.css';
import User from "../../utils/User";
import {FaDoorOpen} from "react-icons/fa6";
import {Tooltip} from "@material-ui/core";
import { useNavigate} from "react-router-dom";
import {FaAngleLeft} from "react-icons/fa";

function Header({title, subtitle, back, disconnect}) {
    const navigate = useNavigate();
    return (
        <div className="header">
            {disconnect &&
                <Tooltip title="Déconnexion" placement="left" >
                <button className="disconnect-btn" onClick={() => {
                    User.disconnect();
                    navigate("/login");
                }}>
                    <FaDoorOpen/>
                </button></Tooltip>
            }
            {back &&
                <Tooltip title="Retour" placement="right" >
                    <button className="back-btn" onClick={() => {
                        navigate(-1);
                    }}>
                        <FaAngleLeft/>
                    </button></Tooltip>
            }
            <img onClick={() => {
                navigate("/");
            }}
                 src={process.env.PUBLIC_URL+"/logo.png"} className="App-logo" alt="Logo de FreshPerf"></img>
            {title !== null &&
                <h1 className="main-title">{title}</h1>
            }
            {subtitle !== null &&
                <p className="main-subtitle">{subtitle}</p>
            }

        </div>
    );
}

export default Header;