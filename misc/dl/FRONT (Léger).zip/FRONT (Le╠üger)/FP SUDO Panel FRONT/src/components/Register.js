import React, { useState } from 'react';
import {Button, TextField} from "@material-ui/core";
import Header from "./parts/Header";
import '../css/main.css';
import '../css/register.css';
import toast, {Toaster} from "react-hot-toast";
import {Navigate, useNavigate} from "react-router-dom";
import { ReactQrCode } from '@devmehq/react-qr-code';


async function registerUser(credentials) {
    return fetch('http://'+process.env.REACT_APP_API+':1222/v1/auth/register', {
        method: 'POST',
        credentials: "include",
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(credentials)
    })
        .then(data => data.json()).catch(err => console.log(JSON.stringify(credentials)));
}


export default function Register() {
    const [login, setLogin] = useState();
    const [firstName, setFirstName] = useState();
    const [lastName, setLastName] = useState();
    const [password, setPassword] = useState();
    const [otpPhase, setOTP] = useState(null);

    const navigate = useNavigate();

    const handleContinue = () => {
        navigate("/");
    }

    const handleSubmit = async e => {
        e.preventDefault();
        const loading = toast.loading("Chargement...");
        const response = await registerUser({
            login,
            firstName,
            lastName,
            password
        });
        if (response.code === 200) {
            toast.success('Inscription réussi', {
                id: loading,
            });
            setOTP(response.message);
        } else {
            toast.error(response.message, {
                id: loading,
            });
        }
    }
    if(otpPhase == null) {
    return (
        <div className="app-container">
            <Toaster/>
            <Header title="Inscription d'un compte FP-SUDO" subtitle="Toute action sera enregistrée." disconnect={true}/>
                <form noValidate onSubmit={handleSubmit}>
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="identifiant"
                        name="identifiant"
                        label="Identifiant"
                        onChange={e => setLogin(e.target.value)}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="firstName"
                        name="firstName"
                        label="Prénom"
                        onChange={e => setFirstName(e.target.value)}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="lastName"
                        name="lastName"
                        label="Nom"
                        onChange={e => setLastName(e.target.value)}
                    />
                    <TextField
                        variant="outlined"
                        margin="normal"
                        required
                        fullWidth
                        id="password"
                        name="password"
                        label="Mot de passe"
                        type="password"
                        onChange={e => setPassword(e.target.value)}
                    />
                    <Button
                        type="submit"
                        className="login_btn"
                        variant="contained"
                        color="primary"
                        fullWidth
                        size="large"
                    >
                        Inscription
                    </Button>
                </form>
        </div>
    );
    } else {
        return (
            <div className="app-container">
                <Toaster/>
                <Header title="Inscription d'un compte FP-SUDO" subtitle="Veuillez enregistrer votre double authentification." disconnect={false}/>
                <div className="qrcode">
                <ReactQrCode value={"otpauth://totp/FP-SUDO?secret="+otpPhase+"&issuer=FreshPerf"}></ReactQrCode>
                </div>
                <h2>Attention! Merci de correctement enregistrer votre code de double authentification pour éviter de rendre l'application inaccessible</h2>
                <h2>Code : {otpPhase}</h2>
                <form noValidate onSubmit={handleContinue}>
                    <Button
                        type="submit"
                        className="login_btn"
                        variant="contained"
                        color="primary"
                        fullWidth
                        size="large"
                    >
                        Continuer
                    </Button>
                </form>
            </div>
        );
    }
}