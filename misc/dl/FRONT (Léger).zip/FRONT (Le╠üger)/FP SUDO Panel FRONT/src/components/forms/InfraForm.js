import Header from "../parts/Header";
import "../../css/infrastructure.css";
import React, {useEffect, useState} from "react";
import '../../css/main.css';
import Rack from "../../utils/Rack";
import Hardware from "../../utils/Hardware";
import "../../css/infraform.css";
import DeviceInformation from "../parts/DeviceInformation";
import toast, {Toaster} from "react-hot-toast";
import {useNavigate, useParams} from "react-router-dom";

const rackList = [];

const hardwareTypeList = [];
let defHardwareType;


Hardware.getTypes().forEach((hardwareType) => {
    if(!defHardwareType) {
        defHardwareType = hardwareType;
    }
    hardwareTypeList.push(<option value={hardwareType.id}>{hardwareType.name}</option>);
});

function InfraForm() {
    let [request, setRequest] = useState("http://"+process.env.REACT_APP_API+":1222/v1/hardware/create");
    let { hardwareID } = useParams();
    const navigate = useNavigate();
    const [racks, setRacks] = useState([]);
    const [hasFetchedEditable, setHasFetchedEditable] = useState(false);
    const [editingHardware, setEditingHardware] = useState();

    useEffect(() => {
        const fetchEditableHardware = async () => {
            try {
                const hardware = await Hardware.get(hardwareID);
                setFormData({
                    Description: hardware.markdown,
                    Rack: hardware.rackID,
                    Type: hardware.hardwareName,
                    Comment: hardware.comment,
                    Buttons: hardware.buttons

                })
                setEditingHardware(hardware);
                setRequest("http://"+process.env.REACT_APP_API+":1222/v1/hardware/edit");
                setHasFetchedEditable(true);

            } catch (exception) {
                console.log(exception);
            }

        };

        if (!hasFetchedEditable && hardwareID != null) {
            fetchEditableHardware();
        }
    }, [hasFetchedEditable, hardwareID]);

    const [formData, setFormData] = useState({
        Rack: null,
        Type: defHardwareType.id,
        Description: 'Ma super machine...',
        Buttons: [{ key: 'Bouton', value: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ' }],
        Comment: 'Mon super commentaire sur ma super machine...',
    });

    const fetchRacks = async () => {
        return await Rack.getAll().then((data) => {
            rackList.length = 0;
            setRacks(data);
            data.map((rack) => {
                if(formData.Rack == null) {
                    setRack(rack.id);
                }
                rackList.push(<option value={rack.id}>{rack.name}</option>);
                return rack;
            });
        }).catch((exception) => {
        });
    }

    useEffect(() => {
        fetchRacks();
    }, []);


    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleButtonChange = (index, e) => {
        const updatedButtons = [...formData.Buttons];
        updatedButtons[index][e.target.name] = e.target.value;
        setFormData({
            ...formData,
            Buttons: updatedButtons,
        });
    };

    const setRack = (rackID) => {
      setFormData({
         ...formData,
         Rack: rackID,
      });
    };

    const addNewButton = () => {
        setFormData({
            ...formData,
            Buttons: [...formData.Buttons, { key: '', value: '' }],
        });
    };

    const removeButton = (indexToRemove) => {
        setFormData({
            ...formData,
            Buttons: formData.Buttons.filter((_, index) => index !== indexToRemove),
        });
    };

    const handleSubmit = async e => {
        e.preventDefault();
        const loading = toast.loading("Chargement...");
        let transformedData = {
            markdown: formData.Description,
            hardwareName: formData.Type * 1,
            comment: formData.Comment,
            rackID: formData.Rack * 1,
            buttons: formData.Buttons
        };
        if(hardwareID != null) {
            transformedData = {
                ...transformedData,
                id: hardwareID
            }
        }
        const response = await Hardware.save(request, transformedData);
        if (response.code === 200) {
            toast.success('Machine sauvegardée', {
                id: loading,
            });
            navigate(-1);
        } else {
            toast.error(response.message, {
                id: loading,
            });
        }
    };

    return (
        <div className="app-container">
            <Toaster/>
    <Header back={true} disconnect={true} title="Ajout d'une machine FP-SUDO"/>
            <div className="form-container">
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label htmlFor="Rack">Rack:</label>
                        <select name="Rack" id="Rack" onChange={handleChange} value={(formData.Rack ?? "XX")}>
                            {rackList}
                        </select>
                    </div>
                    <div className="form-group">
                        <label htmlFor="Type">Type:</label>
                        <select name="Type" id="Type" onChange={handleChange} value={formData.Type}>
                            {hardwareTypeList}
                        </select>
                    </div>
                    <div className="form-group">
                        <label htmlFor="Description">Description:</label>
                        <textarea
                            name="Description"
                            id="Description"
                            onChange={handleChange}
                            value={formData.Description}
                        ></textarea>
                    </div>
                    <div className="form-group">
                        <label>Buttons:</label>
                        {formData.Buttons.map((button, index) => (
                            <div key={index} className="button-group">
                                <input
                                    type="text"
                                    name="key"
                                    placeholder="Nom"
                                    value={button.key}
                                    onChange={(e) => handleButtonChange(index, e)}
                                />
                                <input
                                    type="text"
                                    name="value"
                                    placeholder="Lien"
                                    value={button.value}
                                    onChange={(e) => handleButtonChange(index, e)}
                                />
                                <button className="removeButton" type="button" onClick={() => removeButton(index)}>-</button>
                            </div>
                        ))}
                        <button type="button" onClick={addNewButton}>
                            +
                        </button>
                    </div>
                    <div className="form-group">
                        <label htmlFor="Comment">Commentaire :</label>
                        <textarea
                            name="Comment"
                            id="Comment"
                            onChange={handleChange}
                            value={formData.Comment}
                        ></textarea>
                    </div>
                    <button type="submit">{(editingHardware == null ? "Ajouter" : "Editer")} la machine</button>
                </form>
                <DeviceInformation
                    title={(formData.Rack == null ? "XX" : Rack.getRackByIDFromSource(formData.Rack, racks).name) + "-" + Hardware.getHardwareTypeByID(formData.Type).name + "-" + (editingHardware ? (editingHardware.id > 9 ? editingHardware.id : "0" + editingHardware.id) : "XX")}
                    buttons={formData.Buttons}
                    comment={formData.Comment}
                    description={formData.Description}
                    icon={Hardware.getHardwareTypeByID(formData.Type).icon}
                />
            </div></div>
    );
}

export default InfraForm;