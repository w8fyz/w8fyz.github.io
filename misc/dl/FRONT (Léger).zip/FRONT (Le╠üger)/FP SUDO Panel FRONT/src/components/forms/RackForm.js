import Header from "../parts/Header";
import "../../css/infrastructure.css";
import React, {useEffect, useState} from "react";
import '../../css/main.css';
import Rack from "../../utils/Rack";
import "../../css/infraform.css";
import "../../css/rackForm.css";
import DeviceInformation from "../parts/DeviceInformation";
import toast, {Toaster} from "react-hot-toast";
import {Navigate, useNavigate} from "react-router-dom";


function RackForm() {

    const navigate = useNavigate();
    const [name, setName] = useState("");

    const handleNameChange = (event) => {
        setName(event.target.value);
    }


    const handleSubmit = async e => {
        e.preventDefault();
        const loading = toast.loading("Chargement...");

        const response = await Rack.save(name);
        if (response.code === 200) {
            toast.success('Rack sauvegardé', {
                id: loading,
            });
            navigate(-1);
        } else {
            toast.error(response.message, {
                id: loading,
            });
        }
    };

    return (
        <div className="app-container">
            <Toaster/>
            <Header back={true} disconnect={true} title="Création d'une baie FP-SUDO"/>
            <div className="form-container">
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <label htmlFor="Nom">Nom:</label>
                        <textarea
                            name="Nom"
                            id="name"
                            onChange={handleNameChange}
                            value={name}
                        ></textarea>
                    </div>
                    <button type="submit">Créer la baie</button>
                </form>
                <DeviceInformation
                    title={name}
                    buttons={[]}
                    icon={"/hardware/rack.svg"}
                />
            </div></div>
    );
}

export default RackForm;