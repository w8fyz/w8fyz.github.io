import React from "react";
import '../css/header.css';

export default function APIError() {
    return (
        <div className="header">
            <img src={process.env.PUBLIC_URL+"/logo.png"} className="App-logo" alt="Logo de FreshPerf"></img>
            <h1 className="main-title">Uhhhhh...</h1>
            <p className="main-subtitle">C'est un peu gênant, l'API est innaccessible.</p>
        </div>
    );
}