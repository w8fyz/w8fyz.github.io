import React, {useEffect, useState} from "react";
import {
    Button,
    Chip,
    CircularProgress,
    Dialog, DialogActions, DialogContent, DialogContentText,
    DialogTitle,
    FormControl,
    Input,
    InputLabel,
    MenuItem,
    Select
} from "@material-ui/core";
import Header from "./parts/Header";
import {Link, useNavigate} from "react-router-dom";
import "../css/infrastructure.css";
import DeviceInformation from "./parts/DeviceInformation";
import Rack from "../utils/Rack";
import toast, {Toaster} from "react-hot-toast";


export default function Infrastructure() {
    const navigate = useNavigate();
    const [filteredRacks, setFilteredRacks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [hasFetchedRacks, setHasFetchedRacks] = useState(false);
    const [deletingRack, setDeletingRack] = useState({});
    const [isDialogOpen, setDialogOpen] = useState(false);

    useEffect(() => {
        const fetchRacks = async () => {
            try {
                const rackData = await Rack.getAll();
                setFilteredRacks(rackData);
                setHasFetchedRacks(true);
                const filteredRacks = rackData.map((rack) => {
                    return (
                        <DeviceInformation
                            key={rack.id}
                            title={rack.name}
                            buttons={[]}
                            handleEdit={() => navigate("/rack/edit/"+rack.id)}
                            handleDelete={() => askConfirmDeleteRack(rack)}
                            icon={"/hardware/rack.svg"}
                        />
                    );
                });
                setFilteredRacks(filteredRacks);
                setLoading(false);
            } catch (exception) {
                console.log(exception);
            }

        };

        if (!hasFetchedRacks) {
            fetchRacks();
        }
    }, [hasFetchedRacks]);


    const askConfirmDeleteRack = (rack) => {
        setDeletingRack(rack);
        setDialogOpen(true);
    }

    const handleDeleteRack = async () => {
        const loading = toast.loading("Chargement...");
        const response = await Rack.delete(deletingRack.id);
        if (response.code === 200) {
            toast.success('Supression réussi', {
                id: loading,
            });
            setHasFetchedRacks(false);

        } else {
            toast.error(response.message, {
                id: loading,
            });
        }
        setDialogOpen(false);
    }

    return (
        <div className="app-container">
            <Toaster/>
            <Dialog
                open={isDialogOpen}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogTitle id="alert-dialog-title">
                    {"Confirmer la supression de la baie "+(deletingRack.id != null ? deletingRack.name : "")+" ?"}
                </DialogTitle>
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        Cette action est irréversible, les données seront perdues.
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => setDialogOpen(false)}>Annuler</Button>
                    <Button onClick={handleDeleteRack} autoFocus>
                        Confirmer
                    </Button>
                </DialogActions>
            </Dialog>
            <Header title="Gestion machines FP-SUDO" back={true} disconnect={true}/>
            <div className="infra-control-bar">
                <Link className="infra-control simple-btn" to="/rack/create">+</Link>
                <Link className="infra-control text-btn" to="/infra/">Machines</Link>
            </div>
            <div className="device-container">
                {loading ? (
                    <div className="loader"><CircularProgress /></div>
                ) : (
                    filteredRacks
                )}
            </div>
        </div>
    );
}