import React, {useEffect, useState} from "react";
import {
    Button,
    Chip,
    CircularProgress, Dialog, DialogActions, DialogContent,
    DialogContentText, DialogTitle,
    FormControl,
    Input,
    InputLabel,
    MenuItem,
    Select
} from "@material-ui/core";
import Header from "./parts/Header";
import {Link, useNavigate} from "react-router-dom";
import "../css/infrastructure.css";
import Hardware from "../utils/Hardware";
import DeviceInformation from "./parts/DeviceInformation";
import Rack from "../utils/Rack";
import toast, {Toaster} from "react-hot-toast";


export default function Infrastructure() {
    const navigate = useNavigate();
    const [racks, setRacks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [hasFetchedHardwares, setHasFetchedHardwares] = useState(false);
    const [hasFetchedRacks, setHasFetchedRacks] = useState(false);
    const [filteredDevices, setFilteredDevices] = useState([]);
    const [selectedHardwareTypes, setSelectedHardwareTypes] = useState([]);
    const [selectedRacks, setSelectedRacks] = useState([]);
    const [deletingDevice, setDeletingDevice] = useState({});
    const [isDialogOpen, setDialogOpen] = useState(false);

    useEffect(() => {
        const fetchRacks = async () => {
            try {
                const rackData = await Rack.getAll();
                setRacks(rackData);
                setHasFetchedRacks(true);
            } catch (exception) {
                console.log(exception);
            }
        };

        if (!hasFetchedRacks) {
            fetchRacks();
        }
    }, [hasFetchedRacks]);

    const askConfirmDeleteHardware = (device) => {
        setDeletingDevice(device);
        setDialogOpen(true);
    }

    const handleDeleteHardware = async () => {
        const loading = toast.loading("Chargement...");
        const response = await Hardware.delete(deletingDevice.id);
        if (response.code === 200) {
            toast.success('Supression réussi', {
                id: loading,
            });
            setHasFetchedHardwares(false);
        } else {
            toast.error(response.message, {
                id: loading,
            });
        }
        setDialogOpen(false);
    }

    const fetchHardwares = async (racks, hardwareQuery, rackQuery) => {
        try {
            const hardwareData = await Hardware.getList({
                hardwareTypes: hardwareQuery,
                racks: rackQuery
            });
            const newDevices = hardwareData.map((device) => {
                const type = Hardware.getHardwareTypeByID(device.hardwareName);
                return (
                    <DeviceInformation
                        key={device.id}
                        title={Rack.getRackByIDFromSource(device.rackID, racks).name + "-" + type.name + "-" + (device.id > 9 ? device.id : "0" + device.id)}
                        buttons={device.buttons}
                        comment={device.comment}
                        description={device.markdown}
                        icon={type.icon}
                        handleDelete={() => askConfirmDeleteHardware(device)}
                        handleEdit={() => navigate("/infra/edit/"+device.id)}
                    />
                );
            });

            setFilteredDevices(newDevices);
            setLoading(false);
        } catch (exception) {
            console.log(exception);
            setLoading(false);
        }
    };

    useEffect(() => {
        if (hasFetchedRacks && !hasFetchedHardwares) {
            fetchHardwares(racks, selectedHardwareTypes, selectedRacks);
            setHasFetchedHardwares(true);
        }
    }, [racks, hasFetchedRacks, hasFetchedHardwares, selectedHardwareTypes, selectedRacks]);

    useEffect(() => {
        setHasFetchedHardwares(false);
    }, []);

    const handleHardwareTypeChange = (event) => {
        setSelectedHardwareTypes(event.target.value);
        setHasFetchedHardwares(false);
    };

    const handleRackChange = (event) => {
        setSelectedRacks(event.target.value);
        setHasFetchedHardwares(false);
    };

    return (
        <div className="app-container">
            <Toaster/>
            <Dialog
                open={isDialogOpen}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogTitle id="alert-dialog-title">
                    {"Confirmer la supression de la machine "+(deletingDevice.id != null ? Rack.getRackByIDFromSource(deletingDevice.rackID, racks).name
                        + "-" + Hardware.getHardwareTypeByID(deletingDevice.hardwareName).name
                        + "-" + (deletingDevice.id > 9 ? deletingDevice.id : "0" + deletingDevice.id) : "")+" ?"}
                </DialogTitle>
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        Cette action est irréversible, les données seront perdues.
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => setDialogOpen(false)}>Annuler</Button>
                    <Button onClick={handleDeleteHardware} autoFocus>
                        Confirmer
                    </Button>
                </DialogActions>
            </Dialog>
            <Header title="Gestion machines FP-SUDO" back={true} disconnect={true}/>
            <div className="infra-control-bar">
                <Link className="infra-control simple-btn" to="/infra/create">+</Link>
                <Link className="infra-control text-btn" to="/rack/">Baies</Link>
                {(
                    <div className="filter-panel">
                        <FormControl className="filter-select">
                            <InputLabel>Types de machine</InputLabel>
                            <Select
                                multiple
                                value={selectedHardwareTypes}
                                onChange={handleHardwareTypeChange}
                                input={<Input />}
                                renderValue={(selected) => (
                                    <div>
                                        {selected.map((id) => (
                                            <Chip key={id} label={Hardware.getTypes().find(type => type.id === id).name} />
                                        ))}
                                    </div>
                                )}
                            >
                                {Hardware.getTypes().map((type) => (
                                    <MenuItem key={type.id} value={type.id}>
                                        {type.name}
                                    </MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                        <FormControl className="filter-select">
                            <InputLabel>Baies</InputLabel>
                            <Select
                                multiple
                                value={selectedRacks}
                                onChange={handleRackChange}
                                input={<Input />}
                                renderValue={(selected) => (
                                    <div>
                                        {selected.map((id) => (
                                            <Chip key={id} label={racks.find(rack => rack.id === id).name} />
                                        ))}
                                    </div>
                                )}
                            >
                                {racks.map((rack) => (
                                    <MenuItem key={rack.id} value={rack.id}>
                                        {rack.name}
                                    </MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                    </div>
                )}
            </div>
            <div className="device-container">
                {loading ? (
                    <div className="loader"><CircularProgress /></div>
                ) : (
                    filteredDevices
                )}
            </div>
        </div>
    );
}