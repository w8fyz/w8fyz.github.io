import React, {useEffect, useState} from "react";
import Header from "./parts/Header";
import "../css/users.css";
import toast, {Toaster} from "react-hot-toast";
import {useNavigate} from "react-router-dom";
import User from "../utils/User";
import Log from "./parts/Log";
import UserEntity from "./parts/UserEntity";
import {Button, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle} from "@material-ui/core";

export default function Users() {
    const navigate = useNavigate();
    const [users, setUsers] = useState([]);
    const [deletingUser, setDeletingUser] = useState({});
    const [isDialogOpen, setDialogOpen] = useState(false);
    const [hasFetchedUsers, setHasFetchedUsers] = useState(false);

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const data = await User.getAll();
                setHasFetchedUsers(true);
                const formatted = data.map((user) => (
                    <UserEntity
                    firstName={user.firstName}
                    lastName={user.lastName}
                    login={user.login}
                    register={user.register}
                    lastLogin={user.lastLogin}
                    handleDelete={() => {
                        confirmDelete(user);
                    }}
                    />
                ));
                setUsers(formatted);
            } catch (exception) {
                console.log(exception);
            }
        };

        const confirmDelete = (user) => {
            setDeletingUser(user);
            setDialogOpen(true);
        }

        if (!hasFetchedUsers) {
            fetchUsers();
        }
    }, [hasFetchedUsers]);

    const handleDeleteUser = async () => {
        const loading = toast.loading("Chargement...");
        const response = await User.delete(deletingUser.id);
        if (response.code === 200) {
            toast.success('Supression réussie', {
                id: loading,
            });
            setHasFetchedUsers(false);

        } else {
            toast.error(response.message, {
                id: loading,
            });
        }
        setDialogOpen(false);
    }

    return (
        <div className="app-container">
            <Toaster />
            <Dialog
                open={isDialogOpen}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogTitle id="alert-dialog-title">
                    {"Confirmer la supression de l'utilisateur "+(deletingUser.id != null ? deletingUser.firstName + " " + deletingUser.lastName : "")+" ?"}
                </DialogTitle>
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        Cette action est irréversible, les données seront perdues.
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => setDialogOpen(false)}>Annuler</Button>
                    <Button onClick={handleDeleteUser}>
                        Confirmer
                    </Button>
                </DialogActions>
            </Dialog>
            <Header title="Utilisateurs FP-SUDO" back={true} disconnect={true} />
            <div id="users-container">
                {users}
                <div onClick={() => {
                    navigate("/register");
                }} className="add-user"><p>+</p></div>
            </div>
        </div>
    );
}