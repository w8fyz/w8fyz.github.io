package fr.freshperf.fpsudopanelapi.controllers;

import fr.freshperf.fpsudopanelapi.utils.Response;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
public class MainController {

  @RequestMapping("/")
  public String handleMainGetRequest() {
    return Response.get(200, "API is working");
  }

}