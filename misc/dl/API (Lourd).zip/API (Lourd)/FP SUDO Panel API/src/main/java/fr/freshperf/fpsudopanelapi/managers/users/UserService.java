package fr.freshperf.fpsudopanelapi.managers.users;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class UserService implements UserDetailsService {

	  private UserRepository userRepository;

	  public UserService(UserRepository userRepository) {
	    this.userRepository = userRepository;
	  }

	  public UserEntity findByLogin(String login) {
	    return userRepository.findByLogin(login);
	  }

	  public void deleteByLogin(String login) {
	    userRepository.delete(userRepository.findByLogin(login));
	  }

	  public boolean isEmpty() {
		  return userRepository.count() == 0;
	  }

	  public long size() {
		  return userRepository.count();
	  }
	  public Iterable<UserEntity> findAll() {
		  return userRepository.findAll();
	  }

	  public UserEntity save(UserEntity user, String origin) {
		  if(user.getPassword().isBlank()) {
			System.out.println("DETECTED BLANK PASSWORD ORIGIN  "+origin);
		  }
		  if(user.getToken().isBlank()) {
			  System.out.println("DETECTED BLANK 2FA ORIGIN  "+origin);
		  }
	    return userRepository.save(user);
	  }

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		final UserEntity user = userRepository.findByLogin(username);
		if(user == null) {
			throw new UsernameNotFoundException(username);
		}
		UserDetails usr = User.withUsername(user.getLogin()).password(user.getPassword()).authorities("USER").build();
		return usr;
	}

	public UserEntity findbyID(long id) {
		return userRepository.findByid(id);
	}
}
