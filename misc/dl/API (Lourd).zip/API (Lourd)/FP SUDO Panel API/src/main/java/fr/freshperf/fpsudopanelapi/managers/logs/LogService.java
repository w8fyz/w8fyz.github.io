package fr.freshperf.fpsudopanelapi.managers.logs;

import fr.freshperf.fpsudopanelapi.managers.hardware.HardwareRepository;
import fr.freshperf.fpsudopanelapi.managers.users.UserEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

@Service
public class LogService {

    @Autowired
    private LogRepository logRepository;

    public LogService(LogRepository logRepository) {
        this.logRepository = logRepository;
    }

    public ArrayList<LogEntity> getPartLogs(int page) {
        ArrayList<LogEntity> logs = new ArrayList<>();
        logRepository.findAll().forEach(logs::add);
        logs.sort((o1, o2) -> o2.getId().compareTo(o1.getId()));
        ArrayList<LogEntity> partLogs = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            if (logs.size() > page * 10 + i) {
                partLogs.add(logs.get(page * 10 + i));
            }
        }
        return partLogs;
    }

    public int removeOlderThan(long days) {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, (int) -days);
        return logRepository.removeOlderThan(cal.getTimeInMillis());
    }

    public boolean hasNextPage(int page) {
        page++;
        ArrayList<LogEntity> logs = new ArrayList<>();
        logRepository.findAll().forEach(logs::add);
        return logs.size() > page * 10 + 1;
    }

    public void create(String message, UserEntity user) {
        if(user == null) {
            logRepository.save(new LogEntity(message, "SYSTEM"));
            return;
        }
        logRepository.save(new LogEntity(message, user.getFirstName() + " "+user.getLastName()));
    }

    public ArrayList<LogEntity> getAllLogs() {
        ArrayList<LogEntity> logs = new ArrayList<>();
        logRepository.findAll().forEach(logs::add);
        return logs;
    }

}
