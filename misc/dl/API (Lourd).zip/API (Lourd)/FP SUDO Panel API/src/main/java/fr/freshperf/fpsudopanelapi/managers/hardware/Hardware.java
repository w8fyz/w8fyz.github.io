package fr.freshperf.fpsudopanelapi.managers.hardware;

import com.google.gson.Gson;
import fr.freshperf.fpsudopanelapi.managers.hardware.rack.RackEntity;
import fr.freshperf.fpsudopanelapi.utils.Button;
import fr.freshperf.fpsudopanelapi.utils.HashMapConverter;
import jakarta.persistence.*;
import org.hibernate.annotations.Type;
import org.jboss.aerogear.security.otp.api.Hash;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


@Entity
@Table(name = "hardware")
public class Hardware {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;
    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    private String markdown = "";
    private String hardwareName = "";
    private String comment = "";
    private long rackID;

    @OneToMany(cascade = CascadeType.ALL)
    private List<Button> buttons = new ArrayList<Button>();

    public String getMarkdown() {
        return markdown;
    }

    public void setMarkdown(String markdown) {
        this.markdown = markdown;
    }


    public String getHardwareName() {
        return hardwareName;
    }

    public long getRackID() {
        return rackID;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public void setRackID(long rackID) {
        this.rackID = rackID;
    }

    public void setButtons(List<Button> buttons) {
        this.buttons = buttons;
    }

    public List<Button> getButtons() {
        return buttons;
    }

}


