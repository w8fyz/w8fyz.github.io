package fr.freshperf.fpsudopanelapi.managers.hardware;

public class HardwareQuery {

    private int[] hardwareTypes;
    private int[] racks;

    public int[] getHardwareTypes() {
        return hardwareTypes;
    }

    public int[] getRacks() {
        return racks;
    }

    public void setHardwareTypes(int[] hardwareTypes) {
        this.hardwareTypes = hardwareTypes;
    }

    public void setRacks(int[] racks) {
        this.racks = racks;
    }



}
