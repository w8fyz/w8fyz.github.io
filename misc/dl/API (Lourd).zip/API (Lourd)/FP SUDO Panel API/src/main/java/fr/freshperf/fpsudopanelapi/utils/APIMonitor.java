package fr.freshperf.fpsudopanelapi.utils;

import fr.freshperf.fpsudopanelapi.managers.logs.LogService;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class APIMonitor {

    @Autowired private LogService logService;

    @PostConstruct
    public void init() {
        logService.create("API Started", null);
    }

}

