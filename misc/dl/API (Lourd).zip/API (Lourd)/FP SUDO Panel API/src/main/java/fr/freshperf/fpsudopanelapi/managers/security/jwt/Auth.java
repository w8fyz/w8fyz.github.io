package fr.freshperf.fpsudopanelapi.managers.security.jwt;

import fr.freshperf.fpsudopanelapi.managers.users.UserEntity;
import fr.freshperf.fpsudopanelapi.managers.users.UserService;
import fr.freshperf.fpsudopanelapi.utils.JwtUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import jakarta.annotation.Resource;
import org.springframework.stereotype.Component;

@Component
public class Auth {


	private UserService userService;
	private JwtUtils jwtUtils;

	public Auth(JwtUtils jwtUtils, UserService userService) {
		this.jwtUtils = jwtUtils;
		this.userService = userService;
	}

	public boolean isConnected(String jwt) {
		return jwt != null && userService.findByLogin(jwtUtils.getIDFromJwtToken(jwt)) != null;
	}

	public UserEntity getUser(String jwt) {
		UserEntity user = userService.findByLogin(jwtUtils.getIDFromJwtToken(jwt));
		if(jwt != null && user != null) {
			return user;
		}
		return null;
	}

}
