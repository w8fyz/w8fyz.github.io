package fr.freshperf.fpsudopanelapi.managers.hardware.rack;

import fr.freshperf.fpsudopanelapi.managers.hardware.Hardware;
import fr.freshperf.fpsudopanelapi.managers.hardware.HardwareRepository;
import fr.freshperf.fpsudopanelapi.managers.hardware.HardwareService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.reflect.Array;
import java.util.ArrayList;

@Service
public class RackService {


    @Autowired
    private RackRepository rackRepository;

    public RackService(RackRepository rackRepository) {
        this.rackRepository = rackRepository;
    }

    public void delete(RackEntity hardware) {
        rackRepository.delete(hardware);
    }

    public RackEntity findByID(int id) {
        return rackRepository.findByid(id);
    }

    public RackEntity findByName(String name) {
        return rackRepository.findBynameIgnoreCase(name);
    }



    public ArrayList<RackEntity> findAll() {
        ArrayList<RackEntity> match = new ArrayList<>();
        rackRepository.findAll().forEach(match::add);
        return match;
    }


    public void save(RackEntity hardware) {
        rackRepository.save(hardware);
    }

}