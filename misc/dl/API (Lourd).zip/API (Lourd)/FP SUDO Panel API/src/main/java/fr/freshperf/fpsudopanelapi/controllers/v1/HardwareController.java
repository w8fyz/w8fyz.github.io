package fr.freshperf.fpsudopanelapi.controllers.v1;

import com.google.gson.Gson;
import fr.freshperf.fpsudopanelapi.managers.hardware.HardwareQuery;
import fr.freshperf.fpsudopanelapi.managers.hardware.HardwareService;
import fr.freshperf.fpsudopanelapi.managers.hardware.Hardware;
import fr.freshperf.fpsudopanelapi.managers.logs.LogService;
import fr.freshperf.fpsudopanelapi.managers.security.jwt.AuthUtils;
import fr.freshperf.fpsudopanelapi.managers.users.Rank;
import fr.freshperf.fpsudopanelapi.managers.users.UserEntity;
import fr.freshperf.fpsudopanelapi.managers.users.UserService;
import fr.freshperf.fpsudopanelapi.utils.JwtUtils;
import fr.freshperf.fpsudopanelapi.utils.Response;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/v1/hardware")
public class HardwareController {

	@Autowired
	private UserService userService;
	private AuthUtils authUtils;
	private HardwareService hardwareService;

	private LogService logService;

	@Autowired
	JwtUtils jwtUtils;

	public HardwareController(HardwareService hardwareService, LogService logService) {
		this.hardwareService = hardwareService;
		this.logService = logService;
		this.authUtils = new AuthUtils();
	}

	@GetMapping("/delete/{id}")
	public ResponseEntity<String> delete(@PathVariable(value = "id") int id, HttpServletRequest request) {
		UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
		Hardware hardware = hardwareService.findById(id);
		if(self == null || self.getPower() < Rank.ADMIN.getPower()) {
			return ResponseEntity.status(401).body(Response.get(401, "You can't perform this action"));
		}
		if(hardware == null) {
			return ResponseEntity.status(401).body(Response.get(404, "Hardware not found"));
		}
		logService.create("GET /v1/hardware/delete/"+id+" > DELETED ("+hardware.getHardwareName()+")", self);
		hardwareService.delete(hardware);
		return ResponseEntity.status(200).body(Response.get(200, "Successfully deleted"));
	}

	@GetMapping("/get/{id}")
	public ResponseEntity<String> get(@PathVariable(value = "id") int id, HttpServletRequest request) {
		UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
		Hardware hardware = hardwareService.findById(id);
		if(self == null || self.getPower() < Rank.ADMIN.getPower()) {
			return ResponseEntity.status(401).body(Response.get(401, "You can't perform this action"));
		}
		if(hardware == null) {
			return ResponseEntity.status(401).body(Response.get(404, "Hardware not found"));
		}
		logService.create("GET /v1/hardware/get/"+id+" > GET ("+hardware.getHardwareName()+")", self);
		return ResponseEntity.status(200).body(new Gson().toJson(hardwareService.findById(id)));
	}

		@PostMapping("/query")
		public ResponseEntity<String> types(@RequestBody HardwareQuery query, HttpServletRequest request) {
			UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
			if(self == null || self.getPower() < Rank.ADMIN.getPower()) {
				return ResponseEntity.status(401).body(Response.get(401, "You can't perform this action"));
			}
			ArrayList<Hardware> result = new ArrayList<>();
			if(query.getHardwareTypes().length > 0) {
				for(int r : query.getHardwareTypes()) {
					result.addAll(hardwareService.findByHardwareNameContainsIgnoreCase(r+""));
				}
			} else {
				result.addAll(hardwareService.findAll());
			}
			if(query.getRacks().length > 0) {
				ArrayList<Hardware> newResult = new ArrayList<>();
				for(Hardware h : result) {
					for(int r : query.getRacks()) {
						if(h.getRackID() == r) {
							newResult.add(h);
						}
					}
				}
				result.clear();
				result.addAll(newResult);
			}
			logService.create("POST /v1/hardware/query/"+" > GOT NB: ("+result.size()+")", self);
			return ResponseEntity.status(200).body(new Gson().toJson(result));
		}

		@PostMapping("/create")
		public ResponseEntity<String> mappingType(@RequestBody Hardware hardware, HttpServletRequest request) {
			UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
			if(self == null || self.getPower() < Rank.ADMIN.getPower()) {
				return ResponseEntity.status(401).body(Response.get(401, "You can't perform this action"));
			}
			if(hardware.getId() != null && hardwareService.findById(hardware.getId()) != null) {
				return ResponseEntity.status(404).body(Response.get(404, "Hardware already exist"));
			}
			hardwareService.save(hardware);
			logService.create("POST /v1/hardware/create/ > CREATED ("+hardware.getHardwareName()+")", self);
			return ResponseEntity.status(200).body(Response.get(200, "Successfully created hardware"));
		}

		@PostMapping("/edit")
		public ResponseEntity<String> referenceType(@RequestBody Hardware hardware, HttpServletRequest request) {
			UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
			if(self == null || self.getPower() < Rank.ADMIN.getPower()) {
				return ResponseEntity.status(401).body(Response.get(401, "You can't perform this action"));
			}
			if(hardwareService.findById(hardware.getId()) == null) {
				return ResponseEntity.status(404).body(Response.get(404, "Hardware not found"));
			}
			hardwareService.save(hardware);
			logService.create("POST /v1/hardware/edit/ > EDITED ("+hardware.getId()+")", self);
			return ResponseEntity.status(200).body(Response.get(200, "Successfully edited hardware"));
		}

}
