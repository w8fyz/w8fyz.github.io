package fr.freshperf.fpsudopanelapi.managers.users;

import jakarta.persistence.*;

@Entity
@Table(name = "users")
public class UserEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name= "power", unique = false, nullable = true)
	private int power;
	@Column(name= "login", unique = true, nullable = false, length = 20)
	private String login;
	@Column(name= "first_name", nullable = false, length = 20)
	private String firstName;
	@Column(name="last_name", nullable = false, length = 20)
	private String lastName;
	@Column(name="password", nullable = false, unique = false, length = 60)
	private String password;
	@Column(name="lastLogin", nullable = true, unique = false)
	private long lastLogin;
	@Column(name="register", nullable = false, unique = false)
	private long register;
	@Column(name="2faToken", nullable = true, unique = false)
	private String token;


	@Transient
	private String verificationToken;

	public String getVerificationToken() {
		return verificationToken;
	}

	public long getId() {
		return id;
	}

	public Rank getRank() {
		return Rank.getRankByPower(power);
	}

	public String getLogin() {
		return login;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public String getPassword() {
		return password;
	}

	public long getLastLogin() {
		return lastLogin;
	}

	public long getRegister() {
		return register;
	}

	public String getToken() {
		return token;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setRank(Rank rank) {
		this.power = rank.getPower();
	}

	public int getPower() {
		return power;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setLastLogin(long lastLogin) {
		this.lastLogin = lastLogin;
	}

	public void setRegister(long register) {
		this.register = register;
	}

	public void setToken(String token) {
		this.token = token;
	}
}