package fr.freshperf.fpsudopanelapi.controllers.v1;

import java.security.SecureRandom;
import java.util.ArrayList;

import com.google.gson.Gson;
import fr.freshperf.fpsudopanelapi.managers.logs.LogService;
import fr.freshperf.fpsudopanelapi.managers.security.jwt.AuthUtils;
import fr.freshperf.fpsudopanelapi.managers.users.Rank;
import fr.freshperf.fpsudopanelapi.managers.users.UserEntity;
import fr.freshperf.fpsudopanelapi.managers.users.UserService;
import fr.freshperf.fpsudopanelapi.utils.JwtUtils;
import fr.freshperf.fpsudopanelapi.utils.Response;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/user")
public class UserController {

	private UserService userService;
	private LogService logService;

	@Autowired
	JwtUtils jwtUtils;

	private AuthUtils authUtils;

	public UserController(UserService userService, LogService logService) {
		this.userService = userService;
		this.logService = logService;
		this.authUtils = new AuthUtils();
	}

	@GetMapping("/needFirstUser")
	public ResponseEntity<String> needFirstUser() {
		return ResponseEntity.status(200).body(Response.get(200, userService.isEmpty() ? "true" : "false"));
	}

	@GetMapping("/all")
	public ResponseEntity<String> all(HttpServletRequest request) {
		UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
		if(self != null) {
			if(self.getRank() != Rank.SUDO) {
				logService.create("DENIED GET /v1/user/all", self);
				return ResponseEntity.status(401).body(Response.get(401, "You don't have permission"));
			}
			ArrayList<UserEntity> entityArrayList = new ArrayList<>();
			for(UserEntity user : userService.findAll()) {
				UserEntity target = new UserEntity();
				target.setId(user.getId());
				target.setLastLogin(user.getLastLogin());
				target.setRegister(user.getRegister());
				target.setRank(user.getRank());
				target.setFirstName(user.getFirstName());
				target.setLastName(user.getLastName());
				entityArrayList.add(target);
			}
			logService.create("GET /v1/user/all", self);
			return ResponseEntity.status(200).header("Content-Type","text/html; charset=utf-8").body(new Gson().toJson(entityArrayList));
		} else {
			return ResponseEntity.status(401).body(Response.get(401, "You need to be logged"));
		}
	}

	@GetMapping("/me")
	public ResponseEntity<String> me(HttpServletRequest request) {
		UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
		if(self != null) {
			self.setPassword("");
			self.setToken("");
			return ResponseEntity.status(200).body(new Gson().toJson(self));
		} else {
			return ResponseEntity.status(401).body(Response.get(401, "You need to be logged"));
		}
	}

	@GetMapping("/delete/{id}")
	public String delete(@PathVariable(value = "id") int id, HttpServletRequest request) {
		UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
		if(self == null) {
			return Response.get(401, "You can't perform this action");
		}
		if(id == self.getId()) {
			logService.create("ERROR (SELF DELETE) DELETE /v1/user/delete > "+id, self);
			return Response.get(409, "You can't delete yourself");
		}
		if(userService.size() == 1) {
			logService.create("ERROR (LAST USER) DELETE /v1/user/delete > "+id, self);
			return Response.get(409, "You can't delete the last user");
		}
		if(self.getRank() != Rank.SUDO) {
			logService.create("DENIED DELETE /v1/user/delete", self);
			return Response.get(401, "You don't have the permission");
		}
		UserEntity target = userService.findbyID(id);
		if (target != null) {
			logService.create("DELETE /v1/user/delete > "+target.getLogin(), self);
			userService.deleteByLogin(target.getLogin());
			return Response.get(200, "User deleted");
		} else {
			return Response.get(409, "User don't exist");
		}
	}

	@PostMapping("/update")
	public String update(@RequestBody UserEntity user, HttpServletRequest request) {
		UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
		if(self == null) {
			return Response.get(401, "You can't perform this action");
		}
		if(self.getRank() != Rank.SUDO) {
			logService.create("DENIED POST /v1/user/update", self);
			return Response.get(401, "You don't have the permission");
		}
		UserEntity savedUser = userService.findbyID(user.getId());
		if (savedUser != null) {
			if(user.getLogin() != null && !user.getLogin().equals(savedUser.getLogin())) {
				if(userService.findByLogin(user.getLogin()) != null) {
					logService.create("ERROR (ALREADY EXIST) POST /v1/user/update > "+user.getLogin(), self);
					return Response.get(409, "User already exist");
				}
				savedUser.setLogin(user.getLogin());
			}
			if(user.getPassword() != null && !user.getPassword().equals(savedUser.getPassword())) {
				BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(10, new SecureRandom());
				savedUser.setPassword(encoder.encode(user.getPassword()));
			}
			if(user.getPower() != savedUser.getPower()) {
				savedUser.setRank(user.getRank());
			}
			userService.save(savedUser, "/v1/user/update");
			logService.create("POST /v1/user/update > "+user.getLogin(), self);
			return Response.get(200, "User updated");
		} else {
			logService.create("ERROR (DON'T EXIST) POST /v1/user/update > "+user.getLogin(), self);
			return Response.get(409, "User don't exist");
		}
	}

}
