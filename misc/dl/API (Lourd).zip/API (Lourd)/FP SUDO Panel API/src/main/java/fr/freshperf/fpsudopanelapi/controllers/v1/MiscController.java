package fr.freshperf.fpsudopanelapi.controllers.v1;

import com.google.gson.Gson;
import fr.freshperf.fpsudopanelapi.managers.logs.LogService;
import fr.freshperf.fpsudopanelapi.managers.security.jwt.AuthUtils;
import fr.freshperf.fpsudopanelapi.managers.users.Rank;
import fr.freshperf.fpsudopanelapi.managers.users.UserEntity;
import fr.freshperf.fpsudopanelapi.managers.users.UserService;
import fr.freshperf.fpsudopanelapi.utils.JwtUtils;
import fr.freshperf.fpsudopanelapi.utils.Response;
import jakarta.servlet.http.HttpServletRequest;
import org.jboss.aerogear.security.otp.Totp;
import org.jboss.aerogear.security.otp.api.Base32;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.SecureRandom;

@RestController
@RequestMapping("/v1/misc")
public class MiscController {
	private UserService userService;
	private LogService logService;
	private AuthUtils authUtils;

	@Autowired
	JwtUtils jwtUtils;


	public MiscController(UserService userService, LogService logService) {
		this.userService = userService;
		this.logService = logService;
		this.authUtils = new AuthUtils();
	}

	@GetMapping("/ranks")
	public String ranks(HttpServletRequest request) {
		UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
		if(self == null) {
			return Response.get(401, "You can't perform this action");
		}
		logService.create("GET /v1/misc/ranks", self);
		return Response.get(200, new Gson().toJson(Rank.values()));
	}

	@GetMapping("/system/clearlogs")
	public String clearLogs() {
		try {
			int result = logService.removeOlderThan(180);
			logService.create("Older logs cleared ("+result+")", null);
			return Response.get(200, "SUCCESS");
		}catch (Exception e){
			return Response.get(400, e.getMessage());
		}
	}



}
