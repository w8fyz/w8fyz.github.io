package fr.freshperf.fpsudopanelapi.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ReflectionUtils {

    public static List<Class<?>> getClassesExtending(Class<?> superClass, String packageName) {
        List<Class<?>> subClasses = new ArrayList<>();

        Package pkg = Package.getPackage(packageName);
        String packagePath = packageName.replace('.', '/');
        java.net.URL url = Thread.currentThread().getContextClassLoader().getResource(packagePath);

        if (url != null) {
            String directory = url.getFile();
            File packageDirectory = new File(directory);

            if (packageDirectory.exists()) {
                File[] files = packageDirectory.listFiles();
                for (File file : files) {
                    String fileName = file.getName();
                    if (fileName.endsWith(".class")) {
                        String className = packageName + '.' + fileName.substring(0, fileName.length() - 6);
                        try {
                            Class<?> clazz = Class.forName(className);
                            if (superClass.isAssignableFrom(clazz) && !superClass.equals(clazz)) {
                                subClasses.add(clazz);
                            }
                        } catch (ClassNotFoundException e) {
                            // Handle exception
                        }
                    }
                }
            }
        }

        return subClasses;
    }
}
