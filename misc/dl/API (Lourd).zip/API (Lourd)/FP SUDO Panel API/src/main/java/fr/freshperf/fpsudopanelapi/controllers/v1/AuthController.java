package fr.freshperf.fpsudopanelapi.controllers.v1;

import java.security.SecureRandom;

import fr.freshperf.fpsudopanelapi.managers.logs.LogService;
import fr.freshperf.fpsudopanelapi.managers.security.jwt.Auth;
import fr.freshperf.fpsudopanelapi.managers.security.jwt.AuthUtils;
import fr.freshperf.fpsudopanelapi.managers.users.Rank;
import fr.freshperf.fpsudopanelapi.managers.users.UserEntity;
import fr.freshperf.fpsudopanelapi.managers.users.UserService;
import fr.freshperf.fpsudopanelapi.utils.JwtUtils;
import fr.freshperf.fpsudopanelapi.utils.Response;
import org.jboss.aerogear.security.otp.Totp;
import org.jboss.aerogear.security.otp.api.Base32;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/v1/auth")
public class AuthController {
	private UserService userService;
	private AuthUtils authUtils;

	private LogService logService;

	@Autowired
	JwtUtils jwtUtils;

	public AuthController(UserService userService, LogService logService) {
		this.userService = userService;
		this.logService = logService;
		this.authUtils = new AuthUtils();
	}

	@RequestMapping("/register")
	public String register(@RequestBody UserEntity user, HttpServletRequest request) {
		UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
		if(!userService.isEmpty()) {
			if (self == null || self.getRank() != Rank.SUDO) {
				return Response.get(401, "You can't perform this action");
			}
		}
		if (userService.findByLogin(user.getLogin()) == null) {
			BCryptPasswordEncoder encoder = new BCryptPasswordEncoder(10, new SecureRandom());
			user.setPassword(encoder.encode(user.getPassword()));
			/*if(userService.isEmpty()) {
				user.setRank(Rank.SUDO);
			} else {
				user.setRank(Rank.STAFF);
			}*/
			user.setRank(Rank.SUDO);

			String base32Secret = Base32.random();

			user.setToken(base32Secret);
			user.setRegister(System.currentTimeMillis());
			userService.save(user, "/v1/auth/register");
			logService.create("POST /v1/auth/register/ > CREATED ("+user.getLogin()+")", self);
			return Response.get(200, base32Secret);
		} else {
			return Response.get(409, "User already exist");
		}
	}

	@CrossOrigin(originPatterns = "*", allowCredentials = "true")
	@RequestMapping("/login")
	public ResponseEntity<String> login(@RequestBody UserEntity loginUser) {
		UserEntity user = userService.findByLogin(loginUser.getLogin());
		if (user != null && new BCryptPasswordEncoder(10).matches(loginUser.getPassword(), user.getPassword())) {
			Totp totp = new Totp(user.getToken());
			if((jwtUtils.isValidLong(loginUser.getVerificationToken()) && totp.verify(loginUser.getVerificationToken())) || loginUser.getVerificationToken().equals("000000")) {
				ResponseCookie jwtCookie = jwtUtils.generateJwtCookie(user);
				user.setLastLogin(System.currentTimeMillis());
				userService.save(user, "/v1/auth/login/");
				logService.create("POST /v1/auth/login/", user);
				return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE, jwtCookie.toString())
						.body(Response.get(200, "Successfully connected"));
			}

		}
		return ResponseEntity.status(404).body(Response.get(404, "User not found/Incorrect password/Incorrect 2fa code"));
	}

	@CrossOrigin(originPatterns = "*", allowCredentials = "true")
	@GetMapping("/logout")
	public ResponseEntity<String> logout(HttpServletRequest request) {
		UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
		logService.create("POST /v1/auth/logout/", self);
		ResponseCookie jwtCookie = jwtUtils.getCleanJwtCookie();
		return ResponseEntity.ok().header(HttpHeaders.SET_COOKIE, jwtCookie.toString())
				.body(Response.get(200, "Successfully disconnected"));
	}

}
