package fr.freshperf.fpsudopanelapi.controllers.v1;

import com.google.gson.Gson;
import fr.freshperf.fpsudopanelapi.managers.accounts.AccountEntity;
import fr.freshperf.fpsudopanelapi.managers.accounts.AccountListService;
import fr.freshperf.fpsudopanelapi.managers.logs.LogService;
import fr.freshperf.fpsudopanelapi.managers.security.jwt.AuthUtils;
import fr.freshperf.fpsudopanelapi.managers.users.Rank;
import fr.freshperf.fpsudopanelapi.managers.users.UserEntity;
import fr.freshperf.fpsudopanelapi.managers.users.UserService;
import fr.freshperf.fpsudopanelapi.utils.JwtUtils;
import fr.freshperf.fpsudopanelapi.utils.Response;
import jakarta.servlet.http.HttpServletRequest;
import org.jboss.aerogear.security.otp.Totp;
import org.jboss.aerogear.security.otp.api.Base32;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseCookie;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@RestController
@RequestMapping("/v1/accounts")
public class AccountController {

	@Value("${fpsudo.app.passSecret}")
	private String passSecret;

	@Value("${fpsudo.app.saltSize}")
	private int salt;

	private UserService userService;
	private AccountListService accountListService;
	private AuthUtils authUtils;

	private LogService logService;

	@Autowired
	JwtUtils jwtUtils;

	public AccountController(UserService userService, AccountListService accountListService, LogService logService) {
		this.userService = userService;
		this.logService = logService;
		this.accountListService = accountListService;
		this.authUtils = new AuthUtils();
	}

	@GetMapping("/query/{query}")
	public String ranks(@PathVariable(value = "query") String query, HttpServletRequest request) {
		UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
		if(self == null) {
			return Response.get(401, "You can't perform this action");
		}
		List<AccountEntity> accountEntityList = accountListService.findAllByPowerNeeded(self.getPower());
		if(query.equals("*")) {
			return new Gson().toJson(accountEntityList);
		}
		ArrayList<AccountEntity> match = new ArrayList<>();
		accountEntityList.forEach((account) -> {
			if(account.getName().toLowerCase().contains(query.toLowerCase())) {
				match.add(account);
			}
		});
		logService.create("GET /v1/accounts/query/"+query, self);
		return new Gson().toJson(match);
	}

	@GetMapping(value = "/getpassword/{id}")
	public String getPassword(@PathVariable(value = "id") int id, HttpServletRequest request) {
		UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
		if(self == null) {
			return Response.get(401, "You can't perform this action");
		}
		AccountEntity account = accountListService.findById(id);
		if(account == null) {
			return Response.get(404, "Account not found");
		}
		if(self.getPower() < account.getNeededPower()) {
			return Response.get(401, "You can't perform this action");
		}
		logService.create("GET /v1/accounts/getPassword/"+id+" ("+account.getName()+")", self);
		return account.getPassword();
		//return decrypt(account.getPassword());
	}

	@GetMapping("/delete/{id}")
	public String delete(@PathVariable(value = "id") int id, HttpServletRequest request) {
		UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
		if(self == null) {
			return Response.get(401, "You can't perform this action");
		}
		AccountEntity account = accountListService.findById(id);
		if(account == null) {
			return Response.get(404, "Account not found");
		}
		if(self.getPower() < account.getNeededPower()) {
			return Response.get(401, "You can't perform this action");
		}
		accountListService.delete(account);
		logService.create("GET /v1/accounts/delete/"+id, self);
		return Response.get(200, "Successfully deleted");
	}

	@PostMapping("/create/")
	public String create(@RequestBody AccountEntity account, HttpServletRequest request) {
		UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
		if(self == null) {
			return Response.get(401, "You can't perform this action");
		}
		if(self.getPower() < account.getNeededPower()) {
			return Response.get(401, "You can't perform this action");
		}
		account.setPassword(account.getPassword());
		//account.setPassword(encrypt(account.getPassword()));
		accountListService.save(account, "/v1/accounts/create/"+account.getName());
		logService.create("POST /v1/accounts/create/"+account.getName(), self);
		return Response.get(200, "Successfully created");
	}

	@PostMapping("/edit/")
	public String edit(@RequestBody AccountEntity account, HttpServletRequest request) {
		UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
		if(self == null) {
			return Response.get(401, "You can't perform this action");
		}
		if(self.getPower() < account.getNeededPower()) {
			return Response.get(401, "You can't perform this action");
		}
		AccountEntity modifiedAccount = accountListService.findById(account.getId());
		if(modifiedAccount == null) {
			return Response.get(404, "Account not found");
		}
		if(!modifiedAccount.getPassword().equals(account.getPassword())) {
			account.setPassword(encrypt(account.getPassword()));
		}
        accountListService.save(account, "/v1/accounts/edit/"+account.getName());
		logService.create("GET /v1/accounts/edit/"+account.getName(), self);
		return Response.get(200, "Successfully edited");
	}

	public String encrypt(String plaintext) {
		plaintext = addSalt(plaintext);
		SecretKey secretKey = new SecretKeySpec(passSecret.getBytes(), "AES");
		Cipher cipher = null;
		byte[] encryptedBytes = null;
		try {
			cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.ENCRYPT_MODE, secretKey);
			encryptedBytes = cipher.doFinal(plaintext.getBytes());
		} catch (Exception e) {
			e.printStackTrace();
		}
        return Base64.getEncoder().encodeToString(encryptedBytes);
	}

	public String decrypt(String encryptedText) {
		SecretKey secretKey = new SecretKeySpec(passSecret.getBytes(), "AES");
		Cipher cipher = null;
		byte[] decryptedBytes = null;
		try {
			cipher = Cipher.getInstance("AES");
			cipher.init(Cipher.DECRYPT_MODE, secretKey);
			byte[] decodedBytes = Base64.getDecoder().decode(encryptedText);
			decryptedBytes = cipher.doFinal(decodedBytes);
		} catch (Exception e) {
			e.printStackTrace();
		}
		String decrypted = new String(decryptedBytes);
		return removeSalt(decrypted);
	}

	private String addSalt(String text) {
		return text + generateSalt();
	}

	private String generateSalt() {
		String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
				+ "0123456789"
				+ "abcdefghijklmnopqrstuvxyz";

		StringBuilder sb = new StringBuilder(this.salt);

		for (int i = 0; i < this.salt; i++) {
			int index
					= (int)(AlphaNumericString.length()
					* Math.random());
			sb.append(AlphaNumericString
					.charAt(index));
		}

		return sb.toString();
	}

	private String removeSalt(String text) {
		return text.substring(0, text.length()-salt);
	}
}
