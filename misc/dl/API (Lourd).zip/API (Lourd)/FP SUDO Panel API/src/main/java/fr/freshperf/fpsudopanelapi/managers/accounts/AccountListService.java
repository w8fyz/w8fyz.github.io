package fr.freshperf.fpsudopanelapi.managers.accounts;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AccountListService {


    @Autowired
    private AccountRepository accountRepository;

    public AccountListService(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    public Iterable<AccountEntity> findAll() {
        return accountRepository.findAll();
    }

    public List<AccountEntity> findAllByPowerNeeded(int powerNeeded) {
        ArrayList<AccountEntity> accounts = new ArrayList<>();
        findAll().forEach((account) -> {
            if(account.getNeededPower() <= powerNeeded) {
                AccountEntity target = new AccountEntity();
                target.setId(account.getId());
                target.setName(account.getName());
                target.setUsername(account.getUsername());
                target.setNeededPower(account.getNeededPower());
                accounts.add(target);
            }
        });
        return accounts;
    }

    public AccountEntity findById(long id) {
        return accountRepository.findById(id);
    }

    public AccountEntity findByName(String name) { return accountRepository.findByName(name);}

    public void delete(AccountEntity account) {
        accountRepository.delete(account);
    }



    public void save(AccountEntity account, String origin) {
        if(account.getPassword().isBlank()) {
            System.out.println("DETECTED BLANK PASSWORD ACCOUNT : "+origin);
        }
        accountRepository.save(account);
    }

}
