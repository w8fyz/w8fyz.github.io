package fr.freshperf.fpsudopanelapi.managers.security.jwt;

import fr.freshperf.fpsudopanelapi.managers.users.UserEntity;
import fr.freshperf.fpsudopanelapi.managers.users.UserService;
import fr.freshperf.fpsudopanelapi.utils.JwtUtils;
import fr.freshperf.fpsudopanelapi.utils.Response;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;

public class AuthUtils {

    public UserEntity getSelf(JwtUtils jwtUtils, UserService userService, HttpServletRequest request) {
        String jwt = jwtUtils.getJwtFromCookies(request);
        if(new Auth(jwtUtils, userService).isConnected(jwt)) {
            return userService.findByLogin(jwtUtils.getIDFromJwtToken(jwt));
        }
        return null;
    }

}
