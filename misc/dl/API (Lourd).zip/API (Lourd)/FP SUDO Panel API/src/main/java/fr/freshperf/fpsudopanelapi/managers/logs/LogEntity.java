package fr.freshperf.fpsudopanelapi.managers.logs;

import jakarta.persistence.*;

@Entity(name = "logs")
@Table(name = "logs")
public class LogEntity {

    public LogEntity(String message, String fullName) {
        setMessage(message);
        setFullName(fullName);
        setTimestamp(System.currentTimeMillis());
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String message = "";

    private long timestamp = 0;

    private String fullName = "";

    public LogEntity() {}

    public Long getId() {
        return id;
    }

    public String getMessage() {
        return message;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public String getFullName() {
        return fullName;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
}
