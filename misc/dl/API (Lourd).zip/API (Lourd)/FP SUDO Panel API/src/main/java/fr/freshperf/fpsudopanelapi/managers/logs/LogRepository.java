package fr.freshperf.fpsudopanelapi.managers.logs;


import fr.freshperf.fpsudopanelapi.managers.accounts.AccountEntity;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

public interface LogRepository extends CrudRepository<LogEntity, Long> {
    LogEntity findById(long id);

    @Modifying
    @Transactional
    @Query("DELETE FROM logs WHERE timestamp < :date")
    int removeOlderThan(@Param("date") long date);

}
