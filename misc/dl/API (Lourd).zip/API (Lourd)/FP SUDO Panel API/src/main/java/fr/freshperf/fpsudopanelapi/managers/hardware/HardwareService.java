package fr.freshperf.fpsudopanelapi.managers.hardware;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HardwareService {


    @Autowired
    private HardwareRepository hardwareRepository;

    public HardwareService(HardwareRepository hardwareRepository) {
        this.hardwareRepository = hardwareRepository;
    }

    public List<Hardware> findAll() {
        ArrayList<Hardware> match = new ArrayList<>();
        hardwareRepository.findAll().forEach(match::add);
        return match;
    }

    public List<Hardware> findHardwareByRackIDEquals(long rackID) {
        return hardwareRepository.findHardwareByRackIDEquals(rackID);
    }

    public List<Hardware> findByHardwareNameContainsIgnoreCase(String contains) {
        return hardwareRepository.findByHardwareNameContainsIgnoreCase(contains);
    }

    public Hardware findById(long id) {
        return hardwareRepository.findById(id);
    }

    public void delete(Hardware hardware) {
        hardwareRepository.delete(hardware);
    }


    public void save(Hardware hardware) {
        hardwareRepository.save(hardware);
    }

}
