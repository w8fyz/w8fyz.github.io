package fr.freshperf.fpsudopanelapi.managers.hardware.rack;

import jakarta.persistence.*;

@Entity
@Table(name = "racks")
public class RackEntity {

    public RackEntity(String name) {
        this.name = name;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name= "name", unique = true, nullable = false, length = 20)
    private String name;

    public RackEntity() {

    }

    public long getID() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}
