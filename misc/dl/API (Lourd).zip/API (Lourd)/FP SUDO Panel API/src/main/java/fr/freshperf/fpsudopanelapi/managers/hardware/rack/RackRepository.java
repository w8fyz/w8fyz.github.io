package fr.freshperf.fpsudopanelapi.managers.hardware.rack;

import fr.freshperf.fpsudopanelapi.managers.users.UserEntity;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface RackRepository extends CrudRepository<RackEntity, Long> {

    RackEntity findByid(long id);
    RackEntity findBynameIgnoreCase(String name);

}
