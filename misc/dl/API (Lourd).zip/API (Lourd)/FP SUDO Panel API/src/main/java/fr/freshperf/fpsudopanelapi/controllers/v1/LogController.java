package fr.freshperf.fpsudopanelapi.controllers.v1;

import com.google.gson.Gson;
import fr.freshperf.fpsudopanelapi.managers.logs.LogService;
import fr.freshperf.fpsudopanelapi.managers.security.jwt.AuthUtils;
import fr.freshperf.fpsudopanelapi.managers.users.Rank;
import fr.freshperf.fpsudopanelapi.managers.users.UserEntity;
import fr.freshperf.fpsudopanelapi.managers.users.UserService;
import fr.freshperf.fpsudopanelapi.utils.JwtUtils;
import fr.freshperf.fpsudopanelapi.utils.Response;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/logs")
public class LogController {
	private UserService userService;
	private LogService logService;
	private AuthUtils authUtils;

	@Autowired
	JwtUtils jwtUtils;

	public LogController(UserService userService, LogService logService) {
		this.userService = userService;
		this.logService = logService;
		this.authUtils = new AuthUtils();
	}

	@GetMapping("/get/{page}")
	public ResponseEntity<String> get(@PathVariable(value = "page") int page, HttpServletRequest request) {
		UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
		if(self == null) {
			return ResponseEntity.status(401).body(Response.get(401, "You can't perform this action"));
		}
		return ResponseEntity.status(200).header("Content-Type","text/html; charset=utf-8").body(new Gson().toJson(logService.getPartLogs(page)));
	}

	@GetMapping("/havenext/{page}")
	public String havenext(@PathVariable(value = "page") int page, HttpServletRequest request) {
		UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
		if(self == null) {
			return Response.get(401, "You can't perform this action");
		}
		return Response.get(200, new Gson().toJson(logService.hasNextPage(page)));
	}



}
