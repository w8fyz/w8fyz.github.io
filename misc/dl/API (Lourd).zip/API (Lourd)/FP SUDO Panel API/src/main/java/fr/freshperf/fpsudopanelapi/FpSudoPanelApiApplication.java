package fr.freshperf.fpsudopanelapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FpSudoPanelApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(FpSudoPanelApiApplication.class, args);
    }

}
