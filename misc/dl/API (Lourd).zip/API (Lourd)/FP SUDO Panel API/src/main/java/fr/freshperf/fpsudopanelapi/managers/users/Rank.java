package fr.freshperf.fpsudopanelapi.managers.users;

import java.util.Arrays;

public enum Rank {

    SUDO("Sudoers", 3),
    ADMIN("Admin", 2),
    STAFF("Staff", 1);

    private String name;
    private int power;

    Rank(String name, int power) {
        this.name = name;
        this.power = power;
    }

    public static Rank getRankByPower(int power) {
        return Arrays.stream(values()).filter(rank -> rank.getPower() == power).findFirst().orElse(null);
    }

    public int getPower() {
        return power;
    }

    public String getName() {
        return name;
    }
}
