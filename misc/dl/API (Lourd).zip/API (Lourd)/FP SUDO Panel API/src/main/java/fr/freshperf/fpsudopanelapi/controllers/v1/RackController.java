package fr.freshperf.fpsudopanelapi.controllers.v1;

import com.google.gson.Gson;
import fr.freshperf.fpsudopanelapi.managers.hardware.Hardware;
import fr.freshperf.fpsudopanelapi.managers.hardware.HardwareService;
import fr.freshperf.fpsudopanelapi.managers.hardware.rack.RackEntity;
import fr.freshperf.fpsudopanelapi.managers.hardware.rack.RackService;
import fr.freshperf.fpsudopanelapi.managers.logs.LogService;
import fr.freshperf.fpsudopanelapi.managers.security.jwt.AuthUtils;
import fr.freshperf.fpsudopanelapi.managers.users.Rank;
import fr.freshperf.fpsudopanelapi.managers.users.UserEntity;
import fr.freshperf.fpsudopanelapi.managers.users.UserService;
import fr.freshperf.fpsudopanelapi.utils.JwtUtils;
import fr.freshperf.fpsudopanelapi.utils.Response;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/v1/rack")
public class RackController {
	@Autowired
	private UserService userService;
	private AuthUtils authUtils;

	private RackService rackService;
	private LogService logService;

	@Autowired
	private HardwareService hardwareService;


	@Autowired
	private JwtUtils jwtUtils;

	public RackController(RackService rackService, LogService logService) {
		this.rackService = rackService;
		this.logService = logService;
		this.authUtils = new AuthUtils();
	}

	@GetMapping("/get")
	public ResponseEntity<String> get(HttpServletRequest request) {
		UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
		if(self == null || self.getPower() < Rank.ADMIN.getPower()) {
			return ResponseEntity.status(401).body(Response.get(401, "You can't perform this action"));
		}
		logService.create("GET /v1/rack/get", self);
		return ResponseEntity.status(200).header("Content-Type","text/html; charset=utf-8").body(new Gson().toJson(rackService.findAll()));
	}

	@GetMapping("/delete/{query}")
	public ResponseEntity<String> delete(@PathVariable(value = "query") int query, HttpServletRequest request) {
		UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
		if(self == null || self.getPower() < Rank.ADMIN.getPower()) {
			return ResponseEntity.status(401).body(Response.get(401, "You can't perform this action"));
		}

		RackEntity rack = rackService.findByID(query);

		if(rack == null) {
			return ResponseEntity.status(409).body(Response.get(409, "Rack don't exist"));
		}

		if(!hardwareService.findHardwareByRackIDEquals(rack.getID()).isEmpty()) {
			return ResponseEntity.status(401).body(Response.get(401, "There is hardware with this rack ID, you can't delete it"));
		}
		logService.create("GET /v1/rack/delete/"+query+" > DELETED ("+rack.getName()+")", self);
		rackService.delete(rack);

		return ResponseEntity.status(200).body(Response.get(200, "Rack successfully deleted"));
	}

		@GetMapping("/create/{query}")
		public ResponseEntity<String> create(@PathVariable(value = "query") String query, HttpServletRequest request) {
			UserEntity self = authUtils.getSelf(jwtUtils, userService, request);
			if(self == null || self.getPower() < Rank.ADMIN.getPower()) {
				return ResponseEntity.status(401).body(Response.get(401, "You can't perform this action"));
			}
			if(query == null) {
				return ResponseEntity.status(400).body(Response.get(400, "Query can't be empty"));
			}

			if(rackService.findByName(query) != null) {
				return ResponseEntity.status(409).body(Response.get(409, "Rack already exist"));
			}

			rackService.save(new RackEntity(query));
			logService.create("GET /v1/rack/create/"+query+" > CREATED ("+query+")", self);
			return ResponseEntity.status(200).body(Response.get(200, "Rack successfully created"));
		}

}
