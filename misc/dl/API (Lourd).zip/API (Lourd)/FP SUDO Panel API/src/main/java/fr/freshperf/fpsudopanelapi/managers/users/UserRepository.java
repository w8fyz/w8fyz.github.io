package fr.freshperf.fpsudopanelapi.managers.users;

import org.springframework.data.repository.CrudRepository;

public interface UserRepository extends CrudRepository<UserEntity, Long> {
	
  UserEntity findByLogin(String login);
  UserEntity findByid(long id);
}