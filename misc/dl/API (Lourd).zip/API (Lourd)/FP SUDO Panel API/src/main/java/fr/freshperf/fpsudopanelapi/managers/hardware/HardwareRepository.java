package fr.freshperf.fpsudopanelapi.managers.hardware;

import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface HardwareRepository extends CrudRepository<Hardware, Long> {

    List<Hardware> findByHardwareNameContainsIgnoreCase(String hardwareName);
    Hardware findById(long id);
    List<Hardware> findHardwareByRackIDEquals(long rackID);

}