package fr.freshperf.fpsudopanelapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FpSudoPanelApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
